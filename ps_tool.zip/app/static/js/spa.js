// app/static/js/spa.js
(function () {
  const contentEl = document.getElementById("main-content");
  if (!contentEl) return;

  // Helper: chạy lại <script> trong fragment HTML vừa load
  function runScriptsFrom(container) {
    const existingSrcs = new Set(
      Array.from(document.scripts)
        .map(s => s.src)
        .filter(Boolean)
    );

    const scripts = Array.from(container.querySelectorAll("script"));
    for (const old of scripts) {
      const s = document.createElement("script");
      // Copy attributes
      for (const { name, value } of Array.from(old.attributes)) s.setAttribute(name, value);
      if (old.src) {
        // Tránh nạp lại cùng 1 src nhiều lần
        if (!existingSrcs.has(old.src)) {
          s.async = false;
          document.body.appendChild(s);
        }
      } else {
        s.textContent = old.textContent || "";
        document.body.appendChild(s);
      }
      old.remove();
    }
  }

  async function loadUrl(url, push = true) {
    // thêm ?partial=1 để server chỉ trả body
    const partialUrl = url + (url.includes("?") ? "&" : "?") + "partial=1";
    try {
      const res = await fetch(partialUrl, { headers: { "X-Requested-With": "fetch" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const html = await res.text();

      // Tạo container tạm để bóc tách scripts
      const box = document.createElement("div");
      box.innerHTML = html;

      // Thay thế nội dung trước (loại bỏ script tag trong fragment)
      const temp = box.cloneNode(true);
      temp.querySelectorAll("script").forEach(s => s.remove());
      contentEl.innerHTML = temp.innerHTML;

      // Chạy script (inline + src) nếu fragment có
      runScriptsFrom(box);

      // Active nav theo URL mới
      if (push) {
        history.pushState({ url }, "", url);
      }
      setActiveByUrl(url);
      window.scrollTo({ top: 0, behavior: "instant" });
    } catch (err) {
      console.error(err);
      contentEl.innerHTML = `
        <div class="alert alert-danger mt-3">
          Không tải được nội dung (${String(err)}).
        </div>`;
    }
  }

  function setActiveByUrl(url) {
    const u = new URL(url, location.origin);
    const path = u.pathname || "/";
    document.querySelectorAll('.navbar a.nav-link, .navbar a.navbar-brand').forEach(a => {
      try {
        const ah = new URL(a.href, location.origin);
        const active = (ah.pathname === path) ||
                       (ah.pathname === "/" && path === "/");
        a.classList.toggle("active", active && a.classList.contains("nav-link"));
      } catch {}
    });
  }

  // Intercept click (brand + nav-link)
  document.querySelectorAll('.navbar a.navbar-brand, .navbar a.nav-link').forEach(a => {
    a.addEventListener("click", (e) => {
      // giữ nguyên mở tab mới / chuột giữa / modifier keys
      if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button === 1) return;
      e.preventDefault();
      const href = a.getAttribute("href");
      if (!href || href.startsWith("#")) return;
      const abs = new URL(href, location.origin).toString();
      loadUrl(abs, true);
    });
  });

  // Back/Forward
  window.addEventListener("popstate", (e) => {
    const url = (e.state && e.state.url) || location.href;
    loadUrl(url, /*push*/ false);
  });

  // Khởi tạo theo URL hiện tại
  setActiveByUrl(location.href);
})();
